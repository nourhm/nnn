import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { AuthService,GoogleLoginProvider, SocialUser } from 'angular-6-social-login';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  signinForm: FormGroup;
  user: SocialUser;
  loggedIn: boolean;  
  constructor(private authService: AuthService) { }  
  ngOnInit() {
    //will receive user object that contains profile information of the user 
      this.authService.authState.subscribe((user) => {
      this.user = user;
      this.loggedIn = (user != null);//to be used in the html component
      console.log(this.user);

    });
  }  

  
  signInWithGoogle(): void {
    this.authService.signIn(GoogleLoginProvider.PROVIDER_ID);
    console.log("iddd"+GoogleLoginProvider.PROVIDER_ID);
  }
  signOut(): void {
    this.authService.signOut();
  }
}