// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyC32QrGJ4ygxOnMzSTsuZB5mCI1KT-m5cw",
    authDomain: "test-e3b17.firebaseapp.com",
    databaseURL: "https://test-e3b17.firebaseio.com",
    projectId: "test-e3b17",
    storageBucket: "test-e3b17.appspot.com",
    messagingSenderId: "7177507983",
    appId: "1:7177507983:web:223a630e3a7d206ee2ccfa",
    measurementId: "G-Y1KTX82JTG"}
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
