import { Component, OnInit } from '@angular/core';
import { CoursesService } from '../courses.service';
import {CoursesListComponent} from '../courses-list/courses-list.component';
@Component({
  selector: 'app-courses',
  templateUrl: './courses.component.html',
  styleUrls: ['./courses.component.css']
})
export class CoursesComponent implements OnInit {
  constructor(private coursesservice:CoursesService) { }
  form=this.coursesservice.form;
  formControls=this.coursesservice.form.controls;
  
  ngOnInit() {
  }
  onSubmit(){
    //iza key kenet null yaeni badi e3ml insert 
    //iza laa yaeni lcourse already mawjud badi bas e3mel 3leh update 
    //mn ba3da braje3 inputs null
    if(this.coursesservice.form.get('$key').value==null)
    this.coursesservice.insertCourses(this.coursesservice.form.value);
    else
    this.coursesservice.updateCourse(this.coursesservice.form.value);
    this.coursesservice.form.setValue({
      $key:null,
      Code:'',
      Title:''
    });



  }

}
