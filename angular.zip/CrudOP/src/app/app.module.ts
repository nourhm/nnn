import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';

import {AngularFireModule} from 'angularfire2';
import {AngularFireDatabaseModule} from 'angularfire2/database';

import { AppComponent } from './app.component';
import { CoursesService } from './courses.service';
import { CoursesComponent } from './courses/courses.component';
import { CoursesListComponent } from './courses-list/courses-list.component';
import {environment} from '../environments/environment';

@NgModule({
  declarations: [
    AppComponent,
    CoursesComponent,
    CoursesListComponent  ],
  imports: [
    BrowserModule,ReactiveFormsModule,
    AngularFireDatabaseModule,
    //we saved firebase connection details in environment.ts  
    //and we need to initialize angularfiremodule with the firebase
    AngularFireModule.initializeApp(environment.firebase)
  ],
  providers: [CoursesService],
  bootstrap: [AppComponent]
})
export class AppModule { }
