import { Injectable } from '@angular/core';
import { FormControl,FormGroup ,Validators} from '@angular/forms';
import {AngularFireDatabase,AngularFireList} from'angularfire2/database';
@Injectable({
  providedIn: 'root'
})
export class CoursesService {
  courseList:AngularFireList<any>;
  constructor(private fireb:AngularFireDatabase) { }
  //khla2et form b2alba properties lal course li khla2to bl firebase database 
  //w bzet lwaet mnsta3emla bl html
  form=new FormGroup({
    $key:new FormControl(null),
    Code:new FormControl(''),
    Title:new FormControl('')});

  getCourses(){
    //to get list of courses that I have on firebase
    this.courseList=this.fireb.list('courses');
    //snapshot hasab ma fhemta la hata es7ab list li 3ndi yeha
    return this.courseList.snapshotChanges();
  }

  insertCourses(course){
    this.courseList.push({
      Code:course.Code,
      Title:course.Title,
    });

  }
  editCourse(course){
    this.form.setValue(course);
  }
  updateCourse(course){
    this.courseList.update(course.$key,{
      Code:course.Code,
      Title:course.Title
      
    });
  }
  deleteCourse($key){
    this.courseList.remove($key)

  }

}
