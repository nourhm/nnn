import { Component, OnInit } from '@angular/core';
import { CoursesService } from '../courses.service';
import {AngularFireDatabase,AngularFireList} from'angularfire2/database';


@Component({
  selector: 'app-courses-list',
  templateUrl: './courses-list.component.html',
  styleUrls: ['./courses-list.component.css']
})
export class CoursesListComponent implements OnInit {

  constructor(private coursesservice:CoursesService) {
  }
  form=this.coursesservice.form;
  coursesarray=[];
  ngOnInit() {
 //sta3malna subscribe fct l2n getcustomer btrederli observable
  this.coursesservice.getCourses().subscribe(
      //map bt3meli array 
    
      list =>{
        this.coursesarray=list.map(item=>{//convert the observable into an array
              return{
            $key:item.key,
            ...item.payload.val()//gives all courses details 
          };
        });
      console.log(this.coursesarray);
      });
  }
  editCoursee(course){
  return this.coursesservice.editCourse(course);
}
deletecourse($key){
  this.coursesservice.deleteCourse($key);
}

}
